<?php 

if ( ! defined( 'ABSPATH' ) ) exit; 

/** * Scan posts for broken images AND broken links */ 
function wp_bif_scan_posts() { 

    $post_types = get_post_types(['public' => true]); 

    $args = [ 
        'post_type' => $post_types, 
        'post_status' => 'publish', 
        'posts_per_page' => -1 
    ]; 

    $posts = get_posts( $args ); 
    $results = []; 

    foreach ( $posts as $post ) { 

        $content = $post->post_content; 

        /** * Scan Images */ 
        if ( preg_match_all( '/<img[^>]+src=["\']([^"\']+)["\']/', $content, $matches ) ) { 

            foreach ( $matches[1] as $img ) { 

                if ( wp_bif_is_broken_url( $img ) ) { 

                    $results[] = [ 
                        'type' => 'Image', 
                        'post_id' => $post->ID, 
                        'post_title' => $post->post_title, 
                        'url' => $img, 
                    ];
                    
                } 
            } 
        } 

        /** * Scan Links */ 
        if ( preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\']/', $content, $links ) ) { 
            foreach ( $links[1] as $link ) { 

// Skip anchors, mailto, tel, javascript 
                if ( strpos($link, '#') === 0 || strpos($link, 'mailto:') === 0 || strpos($link, 'tel:') === 0 || strpos($link, 'javascript:') === 0 ) { 

                    continue; 

                } if ( wp_bif_is_broken_url( $link ) ) { 

                    $results[] = [ 
                        'type' => 'Link', 
                        'post_id' => $post->ID, 
                        'post_title' => $post->post_title, 
                        'url' => $link, 
                    ]; 

                } 

            } 

        } 

    } 

    update_option( 'wp_bif_scan_results', $results ); 

    return $results; 

} 

/** * Universal broken checker (for images + links) */ 
function wp_bif_is_broken_url( $url ) { 

    $response = wp_remote_head( $url, [ 'timeout' => 2, 'redirection' => 2 ]);

    if ( is_wp_error( $response ) )
       
       return true; 
   
   $code = wp_remote_retrieve_response_code( $response );
   
   return ( $code >= 400 ); 

} 

/** * Render Results Table */ 
function wp_bif_render_results_table($results, $after_scan = false, $paged = 1, $per_page = 20) { 

   $total_results = count($results); 
   $total_pages = ceil($total_results / $per_page); 
   $paged = max(1, $paged); 
   $offset = ($paged - 1) * $per_page; 

 // Slice results for current page 
   $paged_results = array_slice($results, $offset, $per_page); 
   echo '<div style="margin-bottom: 10px; text-align: right; font-weight: bold;">'; 
   echo __('Results found: ','wp-sbif') . $total_results; 
   echo '</div>'; 
   echo '<table class="widefat striped">'; 
   echo '<tr> <th>'.__("Type","wp-sbif").'</th> <th>'.__("Post","wp-sbif").'</th> <th>'.__("Broken URL","wp-sbif").'</th> </tr>'; 
   
   if ( empty($paged_results) ) { 
       echo '<tr>'; 
       echo '<td colspan="3" style="text-align:center; color: #777;">' .__("No broken images or links found","wp-sbif"). '</td>'; 
       echo '</tr>'; 
       
   } else {
       
       foreach ($paged_results as $item) {
           
           echo '<tr>'; 
           echo '<td><strong>' . esc_html($item['type']) . '</strong></td>'; 
           echo '<td> <a href="' . esc_url(get_permalink($item['post_id'])) . '" target="_blank"> ' . esc_html($item['post_title']) . ' <b>'.esc_html__('Go fix','wp-sbif').'</b> </a> </td>'; 
           echo '<td> <a href="' . esc_url($item['url']) . '" target="_blank" style="color:red;"> ' . esc_url($item['url']) . ' </a> </td>'; 
           echo '</tr>'; 
           
       } 
       
   } 
   echo '</table>'; 

 // Pagination controls 
   if($total_pages > 1){
       
       echo '<div class="tablenav"><div class="tablenav-pages" style="margin-top:10px;">'; 
       
       for($i=1; $i <= $total_pages; $i++){ 
           $class = ($i === $paged) ? 'current-page' : '';
           
           echo '<a href="#" class="wp-bif-page ' . $class . '" data-page="' . $i . '" style="margin:0 3px;">' . $i . '</a>'; 
           
       } 
       echo '</div></div>'; 
   } 
} 

add_action('wp_ajax_wp_bif_get_results_page', function() { 

   check_ajax_referer('wp_bif_scan'); 

   $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1; 

   $per_page = 20; 
   $results = get_option('wp_bif_scan_results', []);
   
   ob_start(); 

   wp_bif_render_results_table($results, false, $paged, $per_page);

   wp_send_json_success(ob_get_clean()); 
   
}); 


/** * AJAX Scan Handler */ 
add_action('wp_ajax_wp_bif_scan', function () {

    check_ajax_referer('wp_bif_scan');

    $offset     = isset($_POST['offset']) ? intval($_POST['offset']) : 0;
    $batch_size = 1;

    $post_types = get_post_types(['public' => true]);

    // Count total posts safely
    $count_query = new WP_Query([
        'post_type'      => $post_types,
        'post_status'    => 'publish',
        'posts_per_page' => 1,
        'fields'         => 'ids'
    ]);

    $total_posts = $count_query->found_posts;

    // If first batch → reset results and set scanning flag
    if ($offset === 0) {
        update_option('wp_bif_scan_results', []);
        set_transient('wp_bif_scanning', 1);
    }

    // If scan was cancelled → stop immediately
    if ( ! get_transient('wp_bif_scanning') ) {
        wp_send_json_success([
            'processed'  => 0,
            'total'      => $total_posts,
            'percentage' => 0,
            'completed'  => true
        ]);
    }

    $query = new WP_Query([
        'post_type'      => $post_types,
        'post_status'    => 'publish',
        'posts_per_page' => $batch_size,
        'offset'         => $offset
    ]);

    $results = get_option('wp_bif_scan_results', []);

    foreach ($query->posts as $post) {

        $content = $post->post_content;

        if (preg_match_all('/<img[^>]+src=["\']([^"\']+)["\']/', $content, $matches)) {
            foreach ($matches[1] as $img) {
                if (wp_bif_is_broken_url($img)) {
                    $results[] = [
                        'type'       => 'Image',
                        'post_id'    => $post->ID,
                        'post_title' => $post->post_title,
                        'url'        => $img,
                    ];
                }
            }
        }

        if (preg_match_all('/<a[^>]+href=["\']([^"\']+)["\']/', $content, $links)) {
            foreach ($links[1] as $link) {

                if (
                    strpos($link, '#') === 0 ||
                    strpos($link, 'mailto:') === 0 ||
                    strpos($link, 'tel:') === 0 ||
                    strpos($link, 'javascript:') === 0
                ) {
                    continue;
                }

                if (wp_bif_is_broken_url($link)) {
                    $results[] = [
                        'type'       => 'Link',
                        'post_id'    => $post->ID,
                        'post_title' => $post->post_title,
                        'url'        => $link,
                    ];
                }
            }
        }
    }

    update_option('wp_bif_scan_results', $results);

    $processed  = min($offset + $batch_size, $total_posts);
    $percentage = $total_posts > 0 ? round(($processed / $total_posts) * 100) : 100;
    $completed  = $processed >= $total_posts;

    // When scan completes → remove flag
    if ($completed) {
        delete_transient('wp_bif_scanning');
        
        update_option( 'wp_bif_last_scan_time', current_time( 'timestamp' ) );
        
    }
    
    wp_send_json_success([
        'processed'  => $processed,
        'total'      => $total_posts,
        'percentage' => $percentage,
        'completed'  => $completed
    ]);
});



add_action('wp_ajax_wp_bif_clear_results', function () { 

    check_ajax_referer('wp_bif_scan'); 

    update_option('wp_bif_scan_results', []); 
    wp_send_json_success();
    
});


add_action('wp_ajax_wp_bif_clean_all', function () {
    
    check_ajax_referer('wp_bif_scan');

    delete_transient('wp_bif_scanning'); // stop scan immediately
    update_option('wp_bif_scan_results', []);

    wp_send_json_success();
});