<?php

if ( ! defined( 'ABSPATH' ) ) exit; 

add_action( 'admin_menu', function () { 

    add_menu_page( 
        __('Broken Assets Scanner & Fixer','wp-sbif'), 
        __('Broken Assets Scanner','wp-sbif'), 
        'manage_options', 'wp-bif', 
        'wp_bif_admin_page', 
        'dashicons-format-image' );
}); 

function wp_bif_admin_page() { 

    // Get stored results 

    $results = get_option( 'wp_bif_scan_results', [] ); 

    ?>
    
    <div id="broken-assets-mobile-message">
        <h1><?php esc_html_e('Broken Assets Scanner & Fixer','wp-sbif'); ?></h1>
        <h3><?php esc_html_e('Use PC or Laption to use this plugin','wp-sbif'); ?></h3>
    </div>

    <div class="wrap" id="broken-assets-mobile">
        
        <div style="position: absolute; top: 15px; right: 15px; text-align: center; font-size: 12px;"> 
            <img src="<?php echo esc_url( plugins_url('../assets/img/aminul.jpg', __FILE__) ); ?>" alt="Aminul Sarkar" style="width:40px; height:40px; border-radius:50%; display:block; margin:5px auto; object-fit:cover; border:1px solid #ccc;"> 
            <span style="display:block; color:#555;">Developed by<br><strong><a href="https://aminulsarkar.com" target="_blank">Aminul Sarkar</a></strong></span> 
        </div> 

        <h1><?php esc_html_e('Broken Assets Scanner & Fixer','wp-sbif'); ?></h1>
        <hp><?php esc_html_e('Find broken links & images.','wp-sbif'); ?></hp>
        
        <!-- AJAX Scan Button --> 
        <form method="post" id="wp-bif-scan-form"> 
            <?php wp_nonce_field( 'wp_bif_scan' ); ?> 
            <p> 
                <button type="button" class="button button-primary" id="wp-bif-start"> <?php esc_html_e('Scan for Broken Assets','wp-sbif'); ?> 
            </button> 
            <button class="button" id="wp-bif-cancel" style="display:none;"> <?php esc_html_e('Cancel','wp-sbif'); ?> 
        </button> 
        <button class="button button-secondary" id="wp-bif-clean"> <?php esc_html_e('Clean All Results','wp-sbif'); ?> 
    </button> 
</p> 

<?php
$last_scan = get_option( 'wp_bif_last_scan_time' );
?>

<div id="wp-bif-last-scan" style="margin-bottom:10px;">
    <?php if ( $last_scan ) : ?>
        <strong>Last Scan Completed:</strong>
        <?php echo date_i18n( 'F j, Y g:i A', $last_scan ); ?>
        <?php else : ?>
            <strong>No scan completed yet.</strong>
        <?php endif; ?>
    </div>

    <div id="wp-bif-progress-wrapper" style="display:none; max-width:100%;margin-top:30px;"> 
        <div style="background:#636363; height:30px; border-radius:4px;"> 
            <div id="wp-bif-progress-bar" style="height:30px; width:0%; background:#2271b1; border-radius:4px;"> 
            </div> 
        </div> 
        <div style="margin-top:5px;"> 
            <?php esc_html_e('Progress: ','wp-sbif'); ?>
            <span id="wp-bif-progress-text">0%</span> 
            | <?php esc_html_e('Posts Scanned: ','wp-sbif'); ?>
            <span id="wp-bif-counter">0 / 0</span> 
        </div> 
    </div> 
</form> 
<!-- Result Box --> 
<div id="wp-bif-results"> 
    <?php wp_bif_render_results_table($results); ?> 
</div> 
</div> 
<?php 
}