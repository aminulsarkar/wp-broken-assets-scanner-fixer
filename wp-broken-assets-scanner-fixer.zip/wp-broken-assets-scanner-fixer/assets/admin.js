jQuery(function($){
    
    let currentRequest = null;
    let offset = 0; 
    let scanning = false; 
    
    function scanBatch(){ 
        
        if(!scanning) 
            
            return; 
        
        currentRequest = $.post(wpBIF.ajax, { 
            action: 'wp_bif_scan', 
            offset: offset, 
            _ajax_nonce: wpBIF.nonce 
            
        }, 
        
        function(res){ 
            if(res.success){ 
                
                let data = res.data; 
                
                offset++; 
                
                $('#wp-bif-progress-bar').css('width', data.percentage + '%'); 
                $('#wp-bif-progress-text').text(data.percentage + '%'); 
                $('#wp-bif-counter').text(data.processed + ' / ' + data.total);
                
                if(data.completed){ 
                    
                    scanning = false; 
                    
                    $('#wp-bif-start').prop('disabled', false).text('Scan Again'); 
                    $('#wp-bif-cancel').hide();
                    
                    $.post(wpBIF.ajax, {
                        action: 'wp_bif_get_last_scan_time',
                        _ajax_nonce: wpBIF.nonce
                    }, function(res){
                        if(res.success){
                            $('#wp-bif-last-scan').html(
                                '<strong>Last Scan Completed:</strong> ' + res.data
                                );
                        }
                    });
                    
                    // reload results table 
                    currentRequest = $.post(wpBIF.ajax, {
                        
                        action: 'wp_bif_get_results_page',
                        paged: 1,
                        _ajax_nonce: wpBIF.nonce
                    }, 

                    function(r){
                        if(r.success){
                            
                            $('#wp-bif-results').html(r.data);
                            
        // small delay before refresh
        setTimeout(function(){
            location.reload();
        }, 1500);
        
    }
});
                } else { 
                    
                    scanBatch(); 
                    
                } 
                
            } 
            
        }); 
        
    } 
    
    $('#wp-bif-start').on('click', function(e){
        e.preventDefault();
        
        currentRequest = $.post(wpBIF.ajax, {
            
            action: 'wp_bif_clear_results', 
            _ajax_nonce: wpBIF.nonce 
            
        }); 
        
        offset = 0; 
        scanning = true;
        
        $('#wp-bif-progress-wrapper').show(); 
        $('#wp-bif-progress-bar').css('width','0%'); 
        $('#wp-bif-progress-text').text('0%'); 
        $('#wp-bif-counter').text('0 / 0'); 
        $('#wp-bif-start').prop('disabled', true).text('Scanning...'); 
        $('#wp-bif-cancel').show(); 
        setTimeout(scanBatch, 200); }); 
    
    $('#wp-bif-cancel').on('click', function(){
        
        scanning = false;
        
        $('#wp-bif-start').prop('disabled', false).text('Scan for Broken Images'); 
        
        $('#wp-bif-cancel').hide(); 
        
    }); 
    
    
    // Clean
$('#wp-bif-clean').on('click', function(){ 
    if(!confirm('Are you sure you want to clear all scan results?')) 
        return; 

    // STOP SCANNING
    scanning = false; 
    offset = 0; 

    if(currentRequest){
        currentRequest.abort(); // stop any active AJAX
        currentRequest = null;
    }

    $('#wp-bif-start').prop('disabled', false).text('Scan for Broken Assets'); 
    $('#wp-bif-cancel').hide(); 

    // Clear results
    $.post(wpBIF.ajax, { 
        action: 'wp_bif_clean_all', 
        _ajax_nonce: wpBIF.nonce
    }, function(res){ 
        if(res.success){ 
            // Immediately reload empty table
            $.post(wpBIF.ajax, {
                action: 'wp_bif_get_results_page', 
                paged: 1, 
                _ajax_nonce: wpBIF.nonce
            }, function(r){ 
                if(r.success){ 
                    $('#wp-bif-results').html(r.data); 
                }
            });

            // Reset progress bar
            $('#wp-bif-progress-bar').css('width','0%'); 
            $('#wp-bif-progress-text').text('0%'); 
            $('#wp-bif-counter').text('0 / 0');
        }
    });
});
    
                // Pagination
                $(document).on('click', '.wp-bif-page', function(e){
                    e.preventDefault();

                    let page = $(this).data('page');

                    currentRequest = $.post(wpBIF.ajax, {
                        action: 'wp_bif_get_results_page',
                        paged: page,
                        _ajax_nonce: wpBIF.nonce
                    }, function(res){
                        if(res.success){
                            $('#wp-bif-results').html(res.data);
                        }
                    });
                }); 
                
            });