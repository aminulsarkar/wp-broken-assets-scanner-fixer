<?php
/**
 * Plugin Name: WP Broken Assets Scanner & Fixer
 * Plugin URI: https://aminulsarkar.com
 * Description: Scan and fix broken images and links across the site's posts, pages and other custom post types.
 * Version: 1.0.0
 * Author: Aminul Sarkar
 * Author URI: https://aminulsarkar.com
 * Domain Path: /languages
 * Text Domain: wp-sbif
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Load Translation
function sbif_load_textdomain() {
    load_plugin_textdomain( 'wp-sbif', false, basename( dirname( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'sbif_load_textdomain' );

define( 'WP_BIF_PATH', plugin_dir_path( __FILE__ ) );
define( 'WP_BIF_URL', plugin_dir_url( __FILE__ ) );

require_once WP_BIF_PATH . 'includes/admin-menu.php';
require_once WP_BIF_PATH . 'includes/scanner.php';


add_action('admin_enqueue_scripts', function($hook) {
    if ( $hook !== 'toplevel_page_wp-bif' ) return; // Only load on plugin page

    wp_enqueue_script(
        'wp-bif-admin',
        WP_BIF_URL . 'assets/admin.js',
        ['jquery'],
        '1.0.0',
        true
    );
    
    wp_enqueue_style(
        'wp-bif-admin-css',
        WP_BIF_URL . 'assets/admin.css',
        [],
        '1.0.0',
        'all'
    );

    wp_localize_script('wp-bif-admin', 'wpBIF', [
        'ajax'  => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('wp_bif_scan')
    ]);
});

// Scanner Time Ajax
add_action( 'wp_ajax_wp_bif_get_last_scan_time', function(){

    check_ajax_referer( 'wp_bif_nonce' );

    $last_scan = get_option( 'wp_bif_last_scan_time' );

    if ( $last_scan ) {
        wp_send_json_success(
            date_i18n( 'F j, Y g:i A', $last_scan )
        );
    }

    wp_send_json_success( 'No scan completed yet.' );
});

